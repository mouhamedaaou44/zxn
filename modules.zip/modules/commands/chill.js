const fs = require("fs");
module.exports.config = {
	name: "chill",
    version: "1.0.1",
	hasPermssion: 0,
	credits: "Choru tiktokers", 
	description: "no prefix",
	commandCategory: "No command marks needed",
	usages: "Yo Yo",
    cooldowns: 5, 
};

module.exports.handleEvent = async function({ api, event, client, Users, __GLOBAL }) {
	var { threadID, messageID } = event;
	var name = await Users.getNameUser(event.senderID);
	if (event.body.indexOf("chill")==0 || event.body.indexOf("chill")==0 || event.body.indexOf("chill")==0 || event.body.indexOf("chill")==0 || event.body.indexOf("chill")==0 || event.body.indexOf("chill")==0 || event.body.indexOf("chill")==0 || event.body.indexOf("chill")==0 || event.body.indexOf("chill")==0 || event.body.indexOf("chill")==0 || event.body.indexOf("chill")==0 || event.body.indexOf("chill")==0 ) { 
		var msg = {
				body: "🌃chill⏳🌠",
				attachment: fs.createReadStream(__dirname + `/noprefix/chill.gif`)
			}
			api.sendMessage(msg, threadID, messageID);
    api.setMessageReaction("🌃", event.messageID, (err) => {}, true)
		}
	}
	module.exports.run = function({ api, event, client, __GLOBAL }) {

  }